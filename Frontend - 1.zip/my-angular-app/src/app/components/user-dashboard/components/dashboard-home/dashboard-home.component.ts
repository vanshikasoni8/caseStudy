    import { Component, OnInit } from '@angular/core';
    import { HttpClient, HttpHeaders } from '@angular/common/http';

    @Component({
    selector: 'app-dashboard-home',
    templateUrl: './dashboard-home.component.html',
    styleUrls: ['./dashboard-home.component.scss']
    })
    export class DashboardHomeComponent implements OnInit {
    accountDetails: any = null;
    message = '';

    constructor(private http: HttpClient) {}

    ngOnInit(): void {
        this.fetchUserProfile();
    }

    fetchUserProfile(): void {
        const token = localStorage.getItem('token');
        const accountNumber = localStorage.getItem('accountNumber'); // Make sure this is set at login time

        if (!accountNumber) {
        this.message = 'Account number not found.';
        return;
        }

        const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

        this.http.post<any>('https://localhost:7119/api/Dashboard/dashboard', { accountNumber }, { headers })
        .subscribe({
            next: data => this.accountDetails = data,
            error: err => this.message = 'Failed to load account details.'
        });
    }
    }
