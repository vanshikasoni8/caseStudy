import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { jwtDecode } from 'jwt-decode';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'] 
})
export class LoginComponent {
  credentials = {
    username: '',
    password: ''
  };

  error: string = '';
  loginAttempts: number = 0;
  isLocked: boolean = false;

  constructor(private authService: AuthService, private router: Router) {}

  login() {
    if (this.isLocked) {
      this.error = 'Your account is locked due to multiple failed login attempts.';
      this.router.navigate(['/account-locked']);
      return;
    }

    this.authService.login(this.credentials).subscribe({
      next: (res) => {
        debugger
        this.error = 'Login successful!';
        localStorage.setItem('token', res.token);

        const decodedToken: any = jwtDecode(res.token);

        localStorage.setItem('role', decodedToken.role);
        localStorage.setItem('accountNumber', decodedToken.accountNumber);
        console.log('accountNumber', decodedToken);


        // Determine dashboard route based on role
        const dashboardRoute = decodedToken.role === 'Admin'
          ? '/adminDashboard'
          : decodedToken.role === 'User'
          ? '/userDashboard'
          : '/';

        this.router.navigate([dashboardRoute]);

        // Reset login attempts on success
        this.loginAttempts = 0;
      },
      error: (err) => {
        this.loginAttempts++;
        this.error = 'Login failed. Please check your credentials.';

        if (this.loginAttempts >= 3) {
          this.isLocked = true;
          this.router.navigate(['/account-locked']);
        }
      }
    });
  }
}
