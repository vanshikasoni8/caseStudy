import { Component, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.scss']
})
export class UserDashboardComponent  implements OnInit{

  ngOnInit(): void {
    
  }
  showprofile=false;
  ShowProfile():void{
    this.showprofile=true;
  }
  logout():void{

  }
}
