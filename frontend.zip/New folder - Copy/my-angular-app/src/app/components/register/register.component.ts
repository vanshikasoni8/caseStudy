import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
  user = {
    username: '',
    password: '',
    role:'',
    mobileNumber: ''
  };
  message = '';

  constructor(private authService: AuthService) {}

  register() {
    this.authService.register(this.user).subscribe({
      next: res => this.message = 'Registration successful!',
      error: err => this.message = 'Registration failed.'
    });
  }
}