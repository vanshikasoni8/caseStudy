import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router'; // Import Router for navigation
import {jwtDecode} from 'jwt-decode';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  credentials = {
    username: '',
    password: ''
  };
  message = '';

  constructor(private authService: AuthService,private route:Router) {}

  login() {
    this.authService.login(this.credentials).subscribe({
      next: res => {
        this.message = 'Login successful!';
        
        localStorage.setItem('token', res.token); // Store the token in local storage
        const token = localStorage.getItem('token');
        if (token) {
      const decodedToken: any = jwtDecode(token);
      localStorage.setItem('role',decodedToken.role);
        const dashboard = decodedToken.role === 'Admin' 
        ? 'admin' 
        : decodedToken.role === 'User' 
        ? 'user' 
        : '';
        console.log(res.token); // Log the token to the console
        this.route.navigate([dashboard]); 

        }
      },
      error: err => this.message = 'Login failed.'
    });
  }
}